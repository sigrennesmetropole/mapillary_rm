version = (2, 8, 8)
version_string = "2.8.8"
release_date = "2016.10.20"
