import struct

from ._exceptions import InvalidImageDataError


def split_into_segments(data):
    """Slices JPEG meta data into a list from JPEG binary data.
    """
    if data[0:2] != b"\xff\xd8":
        raise InvalidImageDataError("Given data isn't JPEG.")

    head = 2
    segments = [b"\xff\xd8"]
    while 1:
        if data[head: head + 2] == b"\xff\xda":
            segments.append(data[head:])
            break
        else:
            length = struct.unpack(">H", data[head + 2: head + 4])[0]
            endPoint = head + length + 2
            seg = data[head: endPoint]
            segments.append(seg)
            head = endPoint

        if (head >= len(data)):
            raise InvalidImageDataError("Wrong JPEG data.")
    return segments

def read_exif_from_file(filename):
    """Slices JPEG meta data into a list from JPEG binary data.
    """
    f = open(filename, "rb")
    data = f.read(6)

    if data[0:2] != b"\xff\xd8":
        raise InvalidImageDataError("Given data isn't JPEG.")

    head = data[2:6]
    HEAD_LENGTH = 4
    exif = None
    while 1:
        length = struct.unpack(">H", head[2: 4])[0]

        if head[:2] == b"\xff\xe0":
            segment_data = f.read(length - 2)
            # print("APP0 segment identification is:", segment_data[:4])
            head = f.read(HEAD_LENGTH)
        elif head[:2] == b"\xff\xe1":
            segment_data = f.read(length - 2)
            # print("APP1 segment identification is:", segment_data[:4])
            if segment_data[:4] == b'Exif':
                # return 'Exif' data segment
                exif = head + segment_data
                break
            else:
                # skip this data segment
                head = f.read(HEAD_LENGTH)
        elif head[0:1] == b"\xff":
            f.read(length - 2)
            head = f.read(HEAD_LENGTH)
        else:
            break

    f.close()
    return exif

def get_exif_seg(segments):
    """Returns Exif from JPEG meta data list
    """
    for seg in segments:
        if seg[0:2] == b"\xff\xe1" and seg[4:10] == b"Exif\x00\x00":
            return seg
    return None


def merge_segments(segments, exif=b""):
    """Merges Exif with APP1 manipulations.
    """
    found = False

    for i in range(0, len(segments)):
        if segments[i][0:2] == b"\xff\xe1" and \
           segments[i][4:10] == b"Exif\x00\x00":
            if not found and exif is not None:
                # replace first occurence of APP1:Exif segment
                # print("REPLACING Exif seg %d.." % i)
                segments[i] = exif
                found = True
            else:
                # remove additional occurences of APP1:Exif segment
                # print("REMOVE Exif seg %d.." % i)
                segments.pop(i)

    # no Exif segment in the image, create one now if exists
    if not found and exif:
        segments.insert(1, exif)

    return b"".join(segments)

